async function loadHistoryFromAPI() {
  document.getElementById("historyLoading").classList.remove("hidden");

  try {
    const response = await fetch("https://viespam20-production.up.railway.app/api/history", {
      method: "GET",
      headers: {
        "x-api-key": "secret123", // 👈 thêm API key ở đây
        "Content-Type": "application/json"
      }
    });

    if (!response.ok) {
      throw new Error("HTTP " + response.status + ": " + (await response.text()));
    }

    const data = await response.json();
    renderHistory(data);
  } catch (error) {
    alert("❌ Lỗi tải dữ liệu: " + error.message);
  } finally {
    document.getElementById("historyLoading").classList.add("hidden");
  }
}

function renderHistory(records) {
  const tableBody = document.getElementById("apiHistoryTable");

  if (!records || records.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6" class="px-6 py-8 text-center text-gray-500">
          <div class="flex flex-col items-center">
            <div class="text-4xl mb-2">📋</div>
            <p>Không có dữ liệu</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  const rows = records.map(r => `
    <tr class="hover:bg-gray-50">
      <td class="px-6 py-4">${r.id}</td>
      <td class="px-6 py-4">${new Date(r.timestamp).toLocaleString("vi-VN")}</td>
      <td class="px-6 py-4">${r.mode.toUpperCase()}</td>
      <td class="px-6 py-4">${r.label}</td>
      <td class="px-6 py-4">${r.score.toFixed(1)}%</td>
      <td class="px-6 py-4 truncate max-w-xs" title="${r.text}">${r.text}</td>
    </tr>
  `).join("");

  tableBody.innerHTML = rows;

  // update statistics
  document.getElementById("apiTotalEvents").textContent = records.length;
  document.getElementById("apiSafeEvents").textContent = records.filter(r => r.label === "normal" || r.label === "ham").length;
  document.getElementById("apiWarningEvents").textContent = records.filter(r => r.label === "spam" || r.label === "bullying").length;
  document.getElementById("apiAvgScore").textContent = (records.reduce((sum, r) => sum + r.score, 0) / records.length).toFixed(1);
}
